# SJ Fancy Choice
Elegant online shop for ladies' and kids' fancy items.
Deployed via Vercel.

## Commands
- npm run dev → local test
- npm run build → production build
- npm start → run production
