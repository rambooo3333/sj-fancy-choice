'use client';

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShoppingBag, Phone, MessageCircle } from "lucide-react";

export default function SJFancyChoice() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white text-gray-800 font-poppins">
      <header className="flex justify-between items-center p-6 shadow-sm bg-white sticky top-0 z-10">
        <h1 className="text-2xl font-bold text-rose-600">SJ Fancy Choice</h1>
        <nav className="space-x-6 hidden md:flex">
          <a href="#home" className="hover:text-rose-500">Home</a>
          <a href="#shop" className="hover:text-rose-500">Shop</a>
          <a href="#about" className="hover:text-rose-500">About</a>
          <a href="#contact" className="hover:text-rose-500">Contact</a>
        </nav>
        <Button className="bg-rose-500 hover:bg-rose-600 text-white"><ShoppingBag className="mr-2 h-4 w-4"/>Shop Now</Button>
      </header>

      <section id="home" className="text-center py-20 bg-gradient-to-r from-rose-100 via-white to-rose-100">
        <h2 className="text-4xl md:text-5xl font-extrabold text-rose-600 mb-4">Elegance for Every Occasion</h2>
        <p className="text-lg text-gray-600 mb-6">Discover stylish watches, dazzling jewellery, perfumes & more for ladies and kids.</p>
        <Button className="bg-rose-500 hover:bg-rose-600 text-white">Explore Collection</Button>
      </section>

      <section id="shop" className="py-16 px-6 md:px-12 bg-white">
        <h3 className="text-3xl font-bold text-center text-rose-600 mb-10">Our Collections</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            { title: "Ladies Watches", img: "https://images.unsplash.com/photo-1523275335684-37898b6baf30", desc: "Trendy & elegant timepieces." },
            { title: "Fancy Jewellery", img: "https://images.unsplash.com/photo-1600180758890-6b94519a8ba6", desc: "Bangles, earrings, chains & more." },
            { title: "Perfumes & Slades", img: "https://images.unsplash.com/photo-1590080875832-2db6a49a7e04", desc: "Fragrances & fancy accessories." },
            { title: "Kids Watches", img: "https://images.unsplash.com/photo-1517841905240-472988babdf9", desc: "Colorful and fun for little ones." },
            { title: "Toys (Limited Stock)", img: "https://images.unsplash.com/photo-1596464716121-7b14be9b4a59", desc: "Cute toys for happy kids." },
            { title: "Clutches & Fancy Items", img: "https://images.unsplash.com/photo-1592878849123-ec91a72a6b26", desc: "Stylish accessories for all occasions." },
          ].map((item) => (
            <Card key={item.title} className="hover:shadow-lg transition-shadow duration-300">
              <img src={item.img} alt={item.title} className="w-full h-56 object-cover rounded-t-2xl" />
              <CardContent className="p-4 text-center">
                <h4 className="text-xl font-semibold text-rose-600 mb-2">{item.title}</h4>
                <p className="text-gray-600 text-sm mb-4">{item.desc}</p>
                <Button className="bg-rose-500 hover:bg-rose-600 text-white">Shop Now</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section id="about" className="bg-rose-50 py-16 px-6 md:px-20 text-center">
        <h3 className="text-3xl font-bold text-rose-600 mb-6">About SJ Fancy Choice</h3>
        <p className="max-w-3xl mx-auto text-gray-700 leading-relaxed">
          At <span className="font-semibold">SJ Fancy Choice</span>, we bring you a curated collection of watches, jewellery, perfumes, and accessories that reflect style, beauty, and grace. Whether you're shopping for yourself or your loved ones, our products are handpicked to add a touch of sparkle to every moment.
        </p>
      </section>

      <section id="contact" className="py-16 px-6 md:px-20 text-center bg-white">
        <h3 className="text-3xl font-bold text-rose-600 mb-6">Get in Touch</h3>
        <p className="text-gray-700 mb-4">We’re always happy to help you find the perfect item!</p>
        <div className="flex justify-center space-x-4">
          <Button variant="outline" className="border-rose-500 text-rose-500 hover:bg-rose-50"><Phone className="mr-2 h-4 w-4"/>Call: 0000000000</Button>
          <Button className="bg-green-500 hover:bg-green-600 text-white"><MessageCircle className="mr-2 h-4 w-4"/>WhatsApp Us</Button>
        </div>
      </section>

      <footer className="bg-rose-100 text-center py-6 text-gray-600 text-sm">
        © {new Date().getFullYear()} SJ Fancy Choice — All Rights Reserved.
      </footer>
    </div>
  );
}
